default_app_config = 'maintenance_mode.apps.MaintenanceModeConfig'
__version__ = "1.0.0"